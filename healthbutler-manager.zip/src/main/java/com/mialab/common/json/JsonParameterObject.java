package com.mialab.common.json;

/**
 * 以字符串参数构建json对象 
 *
 */
public interface JsonParameterObject {

	String toJSONString(String para);
	
}
