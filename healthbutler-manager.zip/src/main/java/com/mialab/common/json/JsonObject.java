package com.mialab.common.json;

/**
 * 无参数构建json对象
 *
 */
public interface JsonObject {

	String toJSONString();
	
}
